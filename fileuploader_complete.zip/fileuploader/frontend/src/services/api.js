// ============================================================
// services/api.js — Axios API Client
// ============================================================
// Centralized HTTP client. Automatically attaches JWT token
// and handles auth errors (e.g. expired token → redirect to login).

import axios from 'axios'

const api = axios.create({
  baseURL: '/api', // proxied to http://localhost:5000/api in dev
  timeout: 30000,  // 30 seconds timeout (for large uploads)
})

// ─── Request Interceptor ──────────────────────────────────────
// Runs before every request — attaches JWT if it exists
api.interceptors.request.use(
  (config) => {
    const token = localStorage.getItem('token')
    if (token) {
      config.headers.Authorization = `Bearer ${token}`
    }
    return config
  },
  (error) => Promise.reject(error)
)

// ─── Response Interceptor ─────────────────────────────────────
// Runs after every response — handles global errors
api.interceptors.response.use(
  (response) => response,
  (error) => {
    if (error.response?.status === 401) {
      // Token expired or invalid — clear local storage and redirect to login
      localStorage.removeItem('token')
      localStorage.removeItem('user')
      window.location.href = '/login'
    }
    return Promise.reject(error)
  }
)

export default api
