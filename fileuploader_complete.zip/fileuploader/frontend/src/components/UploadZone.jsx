// ============================================================
// components/UploadZone.jsx — Drag & Drop File Upload
// ============================================================

import { useState, useRef, useCallback } from 'react'
import api from '../services/api'
import '../styles/upload.css'

const ALLOWED_TYPES = ['image/jpeg', 'image/png', 'application/pdf',
  'application/vnd.openxmlformats-officedocument.wordprocessingml.document']
const ALLOWED_EXT = ['.jpg', '.jpeg', '.png', '.pdf', '.docx']
const MAX_SIZE = 10 * 1024 * 1024 // 10 MB

export default function UploadZone({ onSuccess, onError }) {
  const [isDragging, setIsDragging] = useState(false)
  const [uploading, setUploading] = useState(false)
  const [progress, setProgress] = useState(0)
  const [preview, setPreview] = useState(null) // { name, size, type, previewUrl? }
  const inputRef = useRef(null)

  // ─── Validate file before upload ─────────────────────────
  const validate = (file) => {
    if (!ALLOWED_TYPES.includes(file.type)) {
      return `"${file.name}" is not allowed. Use: JPG, PNG, PDF, DOCX`
    }
    if (file.size > MAX_SIZE) {
      return `"${file.name}" exceeds 10 MB limit.`
    }
    return null
  }

  // ─── Handle the actual upload ─────────────────────────────
  const uploadFile = async (file) => {
    const error = validate(file)
    if (error) { onError(error); return }

    // Create a local preview for images
    if (file.type.startsWith('image/')) {
      const url = URL.createObjectURL(file)
      setPreview({ name: file.name, size: file.size, type: file.type, previewUrl: url })
    } else {
      setPreview({ name: file.name, size: file.size, type: file.type })
    }

    setUploading(true)
    setProgress(0)

    const formData = new FormData()
    formData.append('file', file) // "file" must match upload.single("file") in backend

    try {
      const res = await api.post('/upload', formData, {
        headers: { 'Content-Type': 'multipart/form-data' },
        // Track upload progress using XMLHttpRequest events (axios supports this)
        onUploadProgress: (e) => {
          const pct = Math.round((e.loaded / e.total) * 100)
          setProgress(pct)
        },
      })
      onSuccess(res.data.file)
      // Reset preview after short delay
      setTimeout(() => setPreview(null), 1500)
    } catch (err) {
      const msg = err.response?.data?.error || 'Upload failed. Please try again.'
      onError(msg)
      setPreview(null)
    } finally {
      setUploading(false)
      setProgress(0)
    }
  }

  // ─── Drag Events ──────────────────────────────────────────
  const onDragOver = useCallback((e) => {
    e.preventDefault()
    setIsDragging(true)
  }, [])

  const onDragLeave = useCallback((e) => {
    e.preventDefault()
    setIsDragging(false)
  }, [])

  const onDrop = useCallback((e) => {
    e.preventDefault()
    setIsDragging(false)
    const file = e.dataTransfer.files[0]
    if (file) uploadFile(file)
  }, [])

  // ─── File Input Change ────────────────────────────────────
  const onFileChange = (e) => {
    const file = e.target.files[0]
    if (file) uploadFile(file)
    e.target.value = '' // reset so same file can be re-selected
  }

  return (
    <div className="upload-section">
      {/* Drop Zone */}
      <div
        className={`drop-zone ${isDragging ? 'dragging' : ''} ${uploading ? 'uploading' : ''}`}
        onDragOver={onDragOver}
        onDragLeave={onDragLeave}
        onDrop={onDrop}
        onClick={() => !uploading && inputRef.current?.click()}
        role="button"
        tabIndex={0}
        onKeyDown={(e) => e.key === 'Enter' && inputRef.current?.click()}
        aria-label="Upload file"
      >
        <input
          ref={inputRef}
          type="file"
          accept=".jpg,.jpeg,.png,.pdf,.docx"
          onChange={onFileChange}
          style={{ display: 'none' }}
        />

        <div className="drop-zone-content">
          {uploading ? (
            <>
              <div className="upload-icon uploading-pulse">
                <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5">
                  <path d="M12 2v10m0 0l-3-3m3 3l3-3" strokeLinecap="round" strokeLinejoin="round"/>
                  <path d="M3 15v4a2 2 0 002 2h14a2 2 0 002-2v-4" strokeLinecap="round"/>
                </svg>
              </div>
              <p className="drop-main">Uploading...</p>
              <p className="drop-sub">{progress}%</p>
            </>
          ) : (
            <>
              <div className="upload-icon">
                <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5">
                  <path d="M21 15v4a2 2 0 01-2 2H5a2 2 0 01-2-2v-4" strokeLinecap="round" strokeLinejoin="round"/>
                  <polyline points="17 8 12 3 7 8" strokeLinecap="round" strokeLinejoin="round"/>
                  <line x1="12" y1="3" x2="12" y2="15" strokeLinecap="round"/>
                </svg>
              </div>
              <p className="drop-main">
                {isDragging ? 'Release to upload' : 'Drop file here or click to browse'}
              </p>
              <p className="drop-sub">JPG, PNG, PDF, DOCX · Max 10 MB</p>
            </>
          )}
        </div>
      </div>

      {/* Progress bar */}
      {uploading && (
        <div className="progress-bar-track">
          <div className="progress-bar-fill" style={{ width: `${progress}%` }} />
        </div>
      )}

      {/* File Preview Card */}
      {preview && (
        <div className="preview-card">
          {preview.previewUrl ? (
            <img src={preview.previewUrl} alt={preview.name} className="preview-image" />
          ) : (
            <div className="preview-icon">
              {getFileIcon(preview.type)}
            </div>
          )}
          <div className="preview-info">
            <p className="preview-name">{preview.name}</p>
            <p className="preview-size">{formatBytes(preview.size)}</p>
          </div>
          {uploading ? (
            <div className="spinner" />
          ) : (
            <span style={{ color: 'var(--success)', fontSize: '18px' }}>✓</span>
          )}
        </div>
      )}
    </div>
  )
}

// ─── Helpers ──────────────────────────────────────────────────
function formatBytes(bytes) {
  if (bytes < 1024) return `${bytes} B`
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`
  return `${(bytes / (1024 * 1024)).toFixed(2)} MB`
}

function getFileIcon(mimeType) {
  if (mimeType === 'application/pdf') {
    return <span style={{ fontSize: '32px' }}>📄</span>
  }
  if (mimeType.includes('word')) {
    return <span style={{ fontSize: '32px' }}>📝</span>
  }
  return <span style={{ fontSize: '32px' }}>🖼️</span>
}
