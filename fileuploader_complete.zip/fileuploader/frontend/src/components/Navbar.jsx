// ============================================================
// components/Navbar.jsx
// ============================================================

import { useAuth } from '../context/AuthContext'
import { useNavigate } from 'react-router-dom'
import '../styles/navbar.css'

export default function Navbar() {
  const { user, logout } = useAuth()
  const navigate = useNavigate()

  const handleLogout = () => {
    logout()
    navigate('/login')
  }

  return (
    <nav className="navbar">
      <div className="container navbar-inner">
        <div className="navbar-brand">
          <svg width="24" height="24" viewBox="0 0 28 28" fill="none">
            <rect width="28" height="28" rx="8" fill="var(--accent)" />
            <path d="M8 14l4 4 8-8" stroke="#0e0e0f" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"/>
          </svg>
          <span>FileVault</span>
        </div>

        <div className="navbar-right">
          <span className="navbar-user">
            <span className="navbar-user-dot" />
            {user?.username}
          </span>
          <button className="btn btn-ghost btn-sm" onClick={handleLogout}>
            Sign out
          </button>
        </div>
      </div>
    </nav>
  )
}
