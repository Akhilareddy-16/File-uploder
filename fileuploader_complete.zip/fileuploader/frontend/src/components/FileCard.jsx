// ============================================================
// components/FileCard.jsx — Individual File Card
// ============================================================

import api from '../services/api'
import '../styles/filecard.css'

export default function FileCard({ file, onDelete }) {
  const handleDownload = async () => {
    try {
      // Fetch as blob so it forces download (not just open in browser)
      const res = await api.get(`/files/${file.id}/download`, { responseType: 'blob' })
      const url = window.URL.createObjectURL(new Blob([res.data]))
      const a = document.createElement('a')
      a.href = url
      a.download = file.originalName
      a.click()
      window.URL.revokeObjectURL(url)
    } catch {
      alert('Download failed.')
    }
  }

  return (
    <div className="file-card">
      {/* Preview Area */}
      <div className="file-card-preview">
        {file.mimeType?.startsWith('image/') ? (
          <img src={file.url} alt={file.originalName} className="file-thumb" />
        ) : (
          <div className="file-icon">
            {getIcon(file.extension)}
          </div>
        )}

        <span className={`badge badge-${file.extension || 'default'}`}>
          {file.extension?.toUpperCase() || 'FILE'}
        </span>
      </div>

      {/* File Info */}
      <div className="file-card-body">
        <p className="file-name" title={file.originalName}>
          {file.originalName}
        </p>

        <div className="file-meta">
          <span>{formatBytes(file.size)}</span>
          <span className="meta-dot">·</span>
          <span>{formatDate(file.uploadedAt)}</span>
        </div>

        {file.downloadCount > 0 && (
          <div className="file-downloads">
            ↓ {file.downloadCount} download{file.downloadCount !== 1 ? 's' : ''}
          </div>
        )}
      </div>

      {/* Actions */}
      <div className="file-card-actions">
        <button
          className="btn btn-ghost btn-sm"
          onClick={handleDownload}
          title="Download"
        >
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
            <path d="M21 15v4a2 2 0 01-2 2H5a2 2 0 01-2-2v-4" strokeLinecap="round" strokeLinejoin="round"/>
            <polyline points="7 10 12 15 17 10" strokeLinecap="round" strokeLinejoin="round"/>
            <line x1="12" y1="15" x2="12" y2="3" strokeLinecap="round"/>
          </svg>
          Download
        </button>

        <button
          className="btn btn-danger btn-sm"
          onClick={() => onDelete(file.id, file.originalName)}
          title="Delete"
        >
          <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
            <polyline points="3 6 5 6 21 6" strokeLinecap="round"/>
            <path d="M19 6l-1 14a2 2 0 01-2 2H8a2 2 0 01-2-2L5 6" strokeLinecap="round"/>
            <path d="M10 11v6M14 11v6" strokeLinecap="round"/>
          </svg>
          Delete
        </button>
      </div>
    </div>
  )
}

function getIcon(ext) {
  const icons = {
    pdf:  '📄',
    docx: '📝',
    jpg:  '🖼️',
    jpeg: '🖼️',
    png:  '🖼️',
  }
  return <span style={{ fontSize: '36px' }}>{icons[ext] || '📁'}</span>
}

function formatBytes(bytes) {
  if (!bytes) return '—'
  if (bytes < 1024) return `${bytes} B`
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`
  return `${(bytes / (1024 * 1024)).toFixed(2)} MB`
}

function formatDate(dateString) {
  if (!dateString) return '—'
  return new Date(dateString).toLocaleDateString('en-IN', {
    day: '2-digit', month: 'short', year: 'numeric',
  })
}
