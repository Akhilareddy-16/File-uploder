// ============================================================
// components/SearchBar.jsx
// ============================================================

import { useState } from 'react'

export default function SearchBar({ value, onChange }) {
  const [local, setLocal] = useState(value)

  const handleChange = (e) => {
    setLocal(e.target.value)
    // Debounce: wait 400ms after typing stops before calling parent
    clearTimeout(window._searchTimeout)
    window._searchTimeout = setTimeout(() => {
      onChange(e.target.value)
    }, 400)
  }

  const handleClear = () => {
    setLocal('')
    onChange('')
  }

  return (
    <div style={{ position: 'relative', display: 'flex', alignItems: 'center' }}>
      <svg
        width="14" height="14" viewBox="0 0 24 24" fill="none"
        stroke="var(--text-dim)" strokeWidth="2" strokeLinecap="round"
        style={{ position: 'absolute', left: '12px', pointerEvents: 'none' }}
      >
        <circle cx="11" cy="11" r="8" /><line x1="21" y1="21" x2="16.65" y2="16.65" />
      </svg>
      <input
        type="text"
        className="input"
        placeholder="Search files..."
        value={local}
        onChange={handleChange}
        style={{ paddingLeft: '36px', paddingRight: local ? '32px' : '14px', width: '220px', fontSize: '13px' }}
      />
      {local && (
        <button
          onClick={handleClear}
          style={{
            position: 'absolute', right: '10px', background: 'none',
            border: 'none', cursor: 'pointer', color: 'var(--text-muted)',
            fontSize: '16px', lineHeight: 1, padding: '2px'
          }}
          aria-label="Clear search"
        >×</button>
      )}
    </div>
  )
}
