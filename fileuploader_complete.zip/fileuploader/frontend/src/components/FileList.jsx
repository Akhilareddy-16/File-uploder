// ============================================================
// components/FileList.jsx — Grid of Uploaded Files
// ============================================================

import FileCard from './FileCard'
import '../styles/filelist.css'

export default function FileList({ files, loading, onDelete }) {
  if (loading) {
    return (
      <div className="file-grid">
        {Array.from({ length: 6 }).map((_, i) => (
          <div key={i} className="file-card-skeleton" />
        ))}
      </div>
    )
  }

  if (files.length === 0) {
    return (
      <div className="files-empty">
        <div className="files-empty-icon">
          <svg width="40" height="40" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1">
            <path d="M14 2H6a2 2 0 00-2 2v16a2 2 0 002 2h12a2 2 0 002-2V8z" strokeLinecap="round"/>
            <polyline points="14 2 14 8 20 8" strokeLinecap="round"/>
          </svg>
        </div>
        <p className="files-empty-title">No files yet</p>
        <p className="files-empty-sub">Upload your first file using the zone above</p>
      </div>
    )
  }

  return (
    <div className="file-grid">
      {files.map((file) => (
        <FileCard key={file.id} file={file} onDelete={onDelete} />
      ))}
    </div>
  )
}
