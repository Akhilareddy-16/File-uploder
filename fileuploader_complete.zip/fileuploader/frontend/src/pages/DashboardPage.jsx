// ============================================================
// pages/DashboardPage.jsx — Main App Screen
// ============================================================

import { useState, useEffect, useCallback } from 'react'
import { useAuth } from '../context/AuthContext'
import Navbar from '../components/Navbar'
import UploadZone from '../components/UploadZone'
import FileList from '../components/FileList'
import SearchBar from '../components/SearchBar'
import api from '../services/api'
import '../styles/dashboard.css'

export default function DashboardPage() {
  const { user } = useAuth()
  const [files, setFiles] = useState([])
  const [pagination, setPagination] = useState({ total: 0, page: 1, pages: 1 })
  const [loading, setLoading] = useState(true)
  const [search, setSearch] = useState('')
  const [sort, setSort] = useState('newest')
  const [currentPage, setCurrentPage] = useState(1)
  const [toast, setToast] = useState(null)

  // ─── Fetch Files ────────────────────────────────────────────
  const fetchFiles = useCallback(async () => {
    setLoading(true)
    try {
      const res = await api.get('/files', {
        params: { page: currentPage, limit: 10, search, sort },
      })
      setFiles(res.data.files)
      setPagination(res.data.pagination)
    } catch (err) {
      showToast('error', 'Failed to load files.')
    } finally {
      setLoading(false)
    }
  }, [currentPage, search, sort])

  useEffect(() => {
    fetchFiles()
  }, [fetchFiles])

  // ─── Toast Helper ───────────────────────────────────────────
  const showToast = (type, message) => {
    setToast({ type, message })
    setTimeout(() => setToast(null), 4000)
  }

  // ─── After Upload: Refresh List ─────────────────────────────
  const handleUploadSuccess = (newFile) => {
    showToast('success', `"${newFile.originalName}" uploaded successfully!`)
    setCurrentPage(1)
    fetchFiles()
  }

  // ─── Delete File ────────────────────────────────────────────
  const handleDelete = async (fileId, fileName) => {
    if (!confirm(`Delete "${fileName}"? This cannot be undone.`)) return
    try {
      await api.delete(`/files/${fileId}`)
      showToast('success', `"${fileName}" deleted.`)
      fetchFiles()
    } catch {
      showToast('error', 'Failed to delete file.')
    }
  }

  // ─── Search: reset to page 1 ────────────────────────────────
  const handleSearch = (value) => {
    setSearch(value)
    setCurrentPage(1)
  }

  return (
    <div className="dashboard">
      <Navbar />

      <main className="dashboard-main container">
        {/* Toast notification */}
        {toast && (
          <div className={`toast toast-${toast.type} dashboard-toast`}>
            {toast.type === 'success' ? '✓' : '✕'} {toast.message}
          </div>
        )}

        {/* Stats bar */}
        <div className="stats-bar">
          <div className="stat">
            <span className="stat-value">{pagination.total}</span>
            <span className="stat-label">files uploaded</span>
          </div>
          <div className="stat-divider" />
          <div className="stat">
            <span className="stat-value">{user?.username}</span>
            <span className="stat-label">your vault</span>
          </div>
        </div>

        {/* Upload Zone */}
        <UploadZone onSuccess={handleUploadSuccess} onError={(msg) => showToast('error', msg)} />

        {/* File List Header */}
        <div className="files-header">
          <h2 className="files-title">Your Files</h2>
          <div className="files-controls">
            <SearchBar value={search} onChange={handleSearch} />
            <select
              className="input sort-select"
              value={sort}
              onChange={(e) => { setSort(e.target.value); setCurrentPage(1) }}
            >
              <option value="newest">Newest first</option>
              <option value="oldest">Oldest first</option>
              <option value="name">Name A→Z</option>
              <option value="size">Largest first</option>
            </select>
          </div>
        </div>

        {/* File Grid */}
        <FileList
          files={files}
          loading={loading}
          onDelete={handleDelete}
        />

        {/* Pagination */}
        {pagination.pages > 1 && (
          <div className="pagination">
            <button
              className="btn btn-ghost btn-sm"
              disabled={currentPage === 1}
              onClick={() => setCurrentPage((p) => p - 1)}
            >
              ← Prev
            </button>
            <span className="page-info">
              Page {currentPage} of {pagination.pages}
            </span>
            <button
              className="btn btn-ghost btn-sm"
              disabled={currentPage === pagination.pages}
              onClick={() => setCurrentPage((p) => p + 1)}
            >
              Next →
            </button>
          </div>
        )}
      </main>
    </div>
  )
}
