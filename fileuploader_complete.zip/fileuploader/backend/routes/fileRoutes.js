// ============================================================
// routes/fileRoutes.js — File Management Routes
// ============================================================

const express = require("express");
const router = express.Router();
const { protect } = require("../middleware/authMiddleware");
const upload = require("../middleware/uploadMiddleware");
const {
  uploadFile,
  getFiles,
  getFile,
  downloadFile,
  deleteFile,
} = require("../controllers/fileController");

// All file routes require authentication
router.use(protect);

// POST /api/upload — Upload a single file
// "file" is the field name expected from the frontend FormData
router.post("/upload", upload.single("file"), (err, req, res, next) => {
  // Handle Multer errors (file too large, wrong type)
  if (err) {
    return res.status(400).json({ error: err.message });
  }
  next();
}, uploadFile);

// GET /api/files — Get all files (with pagination & search)
router.get("/files", getFiles);

// GET /api/files/:id — Get single file metadata
router.get("/files/:id", getFile);

// GET /api/files/:id/download — Download a file
router.get("/files/:id/download", downloadFile);

// DELETE /api/files/:id — Delete a file
router.delete("/files/:id", deleteFile);

module.exports = router;
