// ============================================================
// server.js — Main entry point for the File Uploader Backend
// ============================================================

const express = require("express");
const mongoose = require("mongoose");
const cors = require("cors");
const helmet = require("helmet");
const rateLimit = require("express-rate-limit");
const path = require("path");
const fs = require("fs");
require("dotenv").config();

const authRoutes = require("./routes/authRoutes");
const fileRoutes = require("./routes/fileRoutes");

const app = express();
const PORT = process.env.PORT || 5000;

// ─── Ensure /uploads folder exists ───────────────────────────
const uploadsDir = path.join(__dirname, "uploads");
if (!fs.existsSync(uploadsDir)) {
  fs.mkdirSync(uploadsDir, { recursive: true });
}

// ─── Security Middleware ──────────────────────────────────────
// Helmet adds various HTTP headers to secure the app
app.use(
  helmet({
    crossOriginResourcePolicy: { policy: "cross-origin" }, // allow images/files to load cross-origin
  })
);

// CORS — allow requests from the frontend
app.use(
  cors({
    origin: process.env.FRONTEND_URL || "http://localhost:5173",
    credentials: true,
  })
);

// Rate limiting — prevent abuse (100 requests per 15 minutes per IP)
const limiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutes
  max: 100,
  message: { error: "Too many requests. Please try again later." },
});
app.use("/api", limiter);

// Stricter rate limit for auth routes (prevent brute force)
const authLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 20,
  message: { error: "Too many login attempts. Please try again later." },
});
app.use("/api/auth", authLimiter);

// ─── Body Parsers ─────────────────────────────────────────────
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// ─── Static File Serving ──────────────────────────────────────
// Makes uploaded files accessible at /uploads/<filename>
app.use("/uploads", express.static(path.join(__dirname, "uploads")));

// ─── API Routes ───────────────────────────────────────────────
app.use("/api/auth", authRoutes);
app.use("/api", fileRoutes);

// ─── Health Check Endpoint ────────────────────────────────────
app.get("/api/health", (req, res) => {
  res.json({ status: "OK", message: "File Uploader API is running!" });
});

// ─── Global Error Handler ─────────────────────────────────────
app.use((err, req, res, next) => {
  console.error("❌ Error:", err.stack);

  // Multer errors (file too large, wrong type, etc.)
  if (err.code === "LIMIT_FILE_SIZE") {
    return res.status(400).json({ error: "File too large. Max size is 10MB." });
  }

  res.status(err.status || 500).json({
    error: err.message || "Internal Server Error",
  });
});

// ─── Connect to MongoDB and Start Server ──────────────────────
mongoose
  .connect(process.env.MONGO_URI || "mongodb://localhost:27017/fileuploader")
  .then(() => {
    console.log("✅ Connected to MongoDB");
    app.listen(PORT, () => {
      console.log(`🚀 Server running on http://localhost:${PORT}`);
    });
  })
  .catch((err) => {
    console.error("❌ MongoDB connection error:", err.message);
    process.exit(1);
  });
