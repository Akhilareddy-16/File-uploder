// ============================================================
// models/File.js — MongoDB schema for uploaded files
// ============================================================

const mongoose = require("mongoose");

const fileSchema = new mongoose.Schema(
  {
    // Original file name (e.g. "resume.pdf")
    originalName: {
      type: String,
      required: true,
    },

    // The name we save it as on disk (uuid-based, unique)
    storedName: {
      type: String,
      required: true,
    },

    // Full path on disk (relative, e.g. "uploads/abc123.pdf")
    filePath: {
      type: String,
      required: true,
    },

    // MIME type (e.g. "image/jpeg", "application/pdf")
    mimeType: {
      type: String,
      required: true,
    },

    // File extension for quick filtering (e.g. "pdf")
    extension: {
      type: String,
    },

    // Size in bytes
    size: {
      type: Number,
      required: true,
    },

    // Which user uploaded this file
    uploadedBy: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User",
      required: true,
    },

    // Optional: download count
    downloadCount: {
      type: Number,
      default: 0,
    },
  },
  {
    timestamps: true, // createdAt = upload timestamp
  }
);

// ─── Index for faster queries ─────────────────────────────────
fileSchema.index({ uploadedBy: 1, createdAt: -1 });
fileSchema.index({ originalName: "text" }); // enables text search on file names

module.exports = mongoose.model("File", fileSchema);
