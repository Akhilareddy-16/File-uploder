// ============================================================
// models/User.js — MongoDB schema for user accounts
// ============================================================

const mongoose = require("mongoose");
const bcrypt = require("bcryptjs");

const userSchema = new mongoose.Schema(
  {
    username: {
      type: String,
      required: [true, "Username is required"],
      unique: true,
      trim: true,
      minlength: [3, "Username must be at least 3 characters"],
      maxlength: [30, "Username cannot exceed 30 characters"],
    },
    email: {
      type: String,
      required: [true, "Email is required"],
      unique: true,
      lowercase: true,
      trim: true,
      match: [/^\S+@\S+\.\S+$/, "Please provide a valid email"],
    },
    password: {
      type: String,
      required: [true, "Password is required"],
      minlength: [6, "Password must be at least 6 characters"],
      select: false, // don't include password in queries by default
    },
  },
  {
    timestamps: true, // adds createdAt and updatedAt automatically
  }
);

// ─── Hash password before saving ─────────────────────────────
// This "pre-save hook" runs every time a user document is saved
userSchema.pre("save", async function (next) {
  // Only hash if password was modified (new user or password change)
  if (!this.isModified("password")) return next();

  // bcrypt salt rounds: higher = more secure but slower (10 is a good balance)
  this.password = await bcrypt.hash(this.password, 10);
  next();
});

// ─── Method to compare passwords ──────────────────────────────
// Used during login to check if entered password matches stored hash
userSchema.methods.comparePassword = async function (candidatePassword) {
  return bcrypt.compare(candidatePassword, this.password);
};

module.exports = mongoose.model("User", userSchema);
