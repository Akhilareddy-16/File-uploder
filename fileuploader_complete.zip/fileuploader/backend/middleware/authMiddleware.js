// ============================================================
// middleware/authMiddleware.js — JWT Authentication Guard
// ============================================================
// This middleware protects routes that require login.
// It checks for a valid JWT token in the Authorization header.

const jwt = require("jsonwebtoken");
const User = require("../models/User");

const protect = async (req, res, next) => {
  try {
    // 1. Check if Authorization header exists and starts with "Bearer"
    const authHeader = req.headers.authorization;
    if (!authHeader || !authHeader.startsWith("Bearer ")) {
      return res.status(401).json({
        error: "Access denied. No token provided. Please log in.",
      });
    }

    // 2. Extract the token (format: "Bearer <token>")
    const token = authHeader.split(" ")[1];

    // 3. Verify the token using our secret key
    const decoded = jwt.verify(token, process.env.JWT_SECRET);

    // 4. Find the user in the database (exclude password)
    const user = await User.findById(decoded.id).select("-password");
    if (!user) {
      return res.status(401).json({
        error: "Token is valid but user no longer exists.",
      });
    }

    // 5. Attach user to the request object so route handlers can use it
    req.user = user;

    // 6. Pass control to the next middleware/route handler
    next();
  } catch (err) {
    if (err.name === "TokenExpiredError") {
      return res.status(401).json({ error: "Token expired. Please log in again." });
    }
    return res.status(401).json({ error: "Invalid token. Please log in again." });
  }
};

module.exports = { protect };
