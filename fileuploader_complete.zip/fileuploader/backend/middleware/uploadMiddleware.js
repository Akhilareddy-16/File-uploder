// ============================================================
// middleware/uploadMiddleware.js — Multer File Upload Config
// ============================================================
// Multer handles multipart/form-data (file uploads).
// We configure: where to store, what to name, what to allow.

const multer = require("multer");
const path = require("path");
const { v4: uuidv4 } = require("uuid");

// ─── Allowed MIME types ───────────────────────────────────────
const ALLOWED_MIME_TYPES = [
  "image/jpeg",
  "image/png",
  "application/pdf",
  "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
];

const ALLOWED_EXTENSIONS = [".jpg", ".jpeg", ".png", ".pdf", ".docx"];

// ─── Storage Configuration ────────────────────────────────────
// DiskStorage saves files to the filesystem (our /uploads folder)
const storage = multer.diskStorage({
  // Where to save the file
  destination: (req, file, cb) => {
    cb(null, path.join(__dirname, "../uploads"));
  },

  // What to name the file on disk
  // We use UUID to guarantee uniqueness and avoid conflicts
  filename: (req, file, cb) => {
    const ext = path.extname(file.originalname).toLowerCase();
    const uniqueName = `${uuidv4()}${ext}`;
    cb(null, uniqueName);
  },
});

// ─── File Filter ──────────────────────────────────────────────
// Called for every file — return an error to reject, null to accept
const fileFilter = (req, file, cb) => {
  const ext = path.extname(file.originalname).toLowerCase();

  // Check both MIME type and extension for extra security
  if (ALLOWED_MIME_TYPES.includes(file.mimetype) && ALLOWED_EXTENSIONS.includes(ext)) {
    cb(null, true); // Accept the file
  } else {
    cb(
      new multer.MulterError(
        "LIMIT_UNEXPECTED_FILE",
        `Invalid file type. Allowed types: JPG, PNG, PDF, DOCX`
      ),
      false
    );
  }
};

// ─── Multer Instance ──────────────────────────────────────────
const upload = multer({
  storage,
  fileFilter,
  limits: {
    fileSize: parseInt(process.env.MAX_FILE_SIZE) || 10 * 1024 * 1024, // 10 MB default
  },
});

module.exports = upload;
