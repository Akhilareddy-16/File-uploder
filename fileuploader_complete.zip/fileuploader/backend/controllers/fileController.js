// ============================================================
// controllers/fileController.js — File CRUD Operations
// ============================================================

const fs = require("fs");
const path = require("path");
const File = require("../models/File");

// ─── POST /api/upload ─────────────────────────────────────────
// Handles file upload — Multer has already saved the file to disk
const uploadFile = async (req, res) => {
  try {
    // If no file was attached, multer won't set req.file
    if (!req.file) {
      return res.status(400).json({ error: "No file uploaded." });
    }

    const { originalname, filename, path: filePath, mimetype, size } = req.file;
    const ext = path.extname(originalname).toLowerCase().replace(".", "");

    // Save file metadata to MongoDB
    const file = await File.create({
      originalName: originalname,
      storedName: filename,
      filePath: `uploads/${filename}`, // relative path
      mimeType: mimetype,
      extension: ext,
      size,
      uploadedBy: req.user._id,
    });

    res.status(201).json({
      message: "File uploaded successfully!",
      file: formatFile(file, req),
    });
  } catch (err) {
    console.error("Upload error:", err);

    // If DB save failed, delete the already-uploaded file to avoid orphans
    if (req.file) {
      fs.unlink(req.file.path, () => {});
    }

    res.status(500).json({ error: "Upload failed. Please try again." });
  }
};

// ─── GET /api/files ───────────────────────────────────────────
// Returns paginated list of files uploaded by the logged-in user
// Supports: ?page=1&limit=10&search=resume&sort=newest
const getFiles = async (req, res) => {
  try {
    const {
      page = 1,
      limit = 10,
      search = "",
      sort = "newest",
    } = req.query;

    const skip = (parseInt(page) - 1) * parseInt(limit);

    // Build query — only show files owned by the current user
    const query = { uploadedBy: req.user._id };

    // Text search on original file name
    if (search) {
      query.originalName = { $regex: search, $options: "i" };
    }

    // Sorting
    const sortOptions = {
      newest: { createdAt: -1 },
      oldest: { createdAt: 1 },
      name: { originalName: 1 },
      size: { size: -1 },
    };
    const sortBy = sortOptions[sort] || sortOptions.newest;

    const [files, total] = await Promise.all([
      File.find(query).sort(sortBy).skip(skip).limit(parseInt(limit)),
      File.countDocuments(query),
    ]);

    res.json({
      files: files.map((f) => formatFile(f, req)),
      pagination: {
        total,
        page: parseInt(page),
        limit: parseInt(limit),
        pages: Math.ceil(total / parseInt(limit)),
      },
    });
  } catch (err) {
    console.error("Get files error:", err);
    res.status(500).json({ error: "Failed to fetch files." });
  }
};

// ─── GET /api/files/:id ───────────────────────────────────────
// Returns a single file's metadata
const getFile = async (req, res) => {
  try {
    const file = await File.findOne({
      _id: req.params.id,
      uploadedBy: req.user._id,
    });

    if (!file) {
      return res.status(404).json({ error: "File not found." });
    }

    res.json({ file: formatFile(file, req) });
  } catch (err) {
    res.status(500).json({ error: "Failed to fetch file." });
  }
};

// ─── GET /api/files/:id/download ─────────────────────────────
// Streams the file for download and increments download count
const downloadFile = async (req, res) => {
  try {
    const file = await File.findOne({
      _id: req.params.id,
      uploadedBy: req.user._id,
    });

    if (!file) {
      return res.status(404).json({ error: "File not found." });
    }

    const absolutePath = path.join(__dirname, "../", file.filePath);

    if (!fs.existsSync(absolutePath)) {
      return res.status(404).json({ error: "File no longer exists on disk." });
    }

    // Increment download count
    await File.findByIdAndUpdate(file._id, { $inc: { downloadCount: 1 } });

    // Trigger browser download with original file name
    res.download(absolutePath, file.originalName);
  } catch (err) {
    console.error("Download error:", err);
    res.status(500).json({ error: "Download failed." });
  }
};

// ─── DELETE /api/files/:id ────────────────────────────────────
// Deletes file from disk AND removes its record from MongoDB
const deleteFile = async (req, res) => {
  try {
    // Only allow the file's owner to delete it
    const file = await File.findOne({
      _id: req.params.id,
      uploadedBy: req.user._id,
    });

    if (!file) {
      return res.status(404).json({ error: "File not found." });
    }

    // Delete from disk
    const absolutePath = path.join(__dirname, "../", file.filePath);
    if (fs.existsSync(absolutePath)) {
      fs.unlinkSync(absolutePath);
    }

    // Delete from MongoDB
    await File.findByIdAndDelete(file._id);

    res.json({ message: "File deleted successfully.", fileId: file._id });
  } catch (err) {
    console.error("Delete error:", err);
    res.status(500).json({ error: "Failed to delete file." });
  }
};

// ─── Helper: Format file object for API response ──────────────
const formatFile = (file, req) => ({
  id: file._id,
  originalName: file.originalName,
  mimeType: file.mimeType,
  extension: file.extension,
  size: file.size,
  downloadCount: file.downloadCount,
  uploadedAt: file.createdAt,
  // Full URL to access/preview the file
  url: `${req.protocol}://${req.get("host")}/${file.filePath}`,
  downloadUrl: `${req.protocol}://${req.get("host")}/api/files/${file._id}/download`,
});

module.exports = { uploadFile, getFiles, getFile, downloadFile, deleteFile };
